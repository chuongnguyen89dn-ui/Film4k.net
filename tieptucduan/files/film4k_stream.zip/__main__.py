import asyncio,re,subprocess,threading,time,math
from pathlib import Path
from urllib.request import Request,urlopen
from urllib.error import URLError
from playwright.async_api import async_playwright

MOVIE="https://film4k.net/movie/spider-man-brand-new-day"
CHROME=r"C:\Users\Trinh\AppData\Local\Chromium\Application\chrome.exe"
PROFILE=r"C:\Users\Trinh\AppData\Local\Chromium\User Data"
VLC=Path(r"C:\Program Files\VideoLAN\VLC\vlc.exe")
OUT=Path("film4k_stream")
UA="Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/150.0.0.0 Safari/537.36"
PNG=b"\x89PNG\r\n\x1a\n"; BUFFER=5

def png_end(b):
    if not b.startswith(PNG): return 0
    p=8
    while p+12<=len(b):
        n=int.from_bytes(b[p:p+4],"big");typ=b[p+4:p+8];e=p+n+12
        if e>len(b):return 0
        if typ==b"IEND":return e
        p=e
    return 0

def get_clean(url,tries=12):
    err=None
    for n in range(tries):
        try:
            with urlopen(Request(url,headers={"User-Agent":UA,"Accept":"*/*"}),timeout=60) as r:b=r.read()
            k=png_end(b);return b[k:] if k else b
        except Exception as e:
            err=e; print(f"\n[RETRY {n+1}/{tries}] {type(e).__name__}: {e}")
            time.sleep(min(2+n*2,15))
    raise err

def parse(body):
    init=None;segs=[];durs=[]
    for s in body.splitlines():
        s=s.strip()
        if s.startswith("#EXT-X-MAP:"):
            m=re.search(r'URI="([^"]+)"',s)
            if m:init=m.group(1)
        elif s.startswith("#EXTINF:"):
            try:durs.append(float(s.split(":",1)[1].split(",",1)[0]))
            except:durs.append(20.)
        elif s and not s.startswith("#") and "workers.dev/tt/" in s:segs.append(s)
    return init,segs,durs

def write_playlist(prefix,initname,done,durs,final=False):
    td=max(1,math.ceil(max(durs[:max(done,1)] or [20])))
    x=["#EXTM3U","#EXT-X-VERSION:7",f"#EXT-X-TARGETDURATION:{td}","#EXT-X-MEDIA-SEQUENCE:0",f'#EXT-X-MAP:URI="{initname}"']
    for i in range(done):
        x += [f"#EXTINF:{(durs[i] if i<len(durs) else 20):.3f},",f"{prefix}_{i:04}.m4s"]
    if final:x.append("#EXT-X-ENDLIST")
    tmp=OUT/f"{prefix}.tmp"; dst=OUT/f"{prefix}.m3u8"
    tmp.write_text("\n".join(x)+"\n",encoding="utf-8");tmp.replace(dst)

def worker(prefix,body,state):
    init,segs,durs=parse(body)
    ip=OUT/f"{prefix}_init.mp4"
    if not ip.exists():ip.write_bytes(get_clean(init))
    done=0
    for i,u in enumerate(segs):
        fp=OUT/f"{prefix}_{i:04}.m4s"
        if not fp.exists() or fp.stat().st_size<100:fp.write_bytes(get_clean(u))
        done=i+1;state[prefix]=done
        write_playlist(prefix,ip.name,done,durs,done==len(segs))
        print(f"\r[{prefix}] {done}/{len(segs)}",end="",flush=True)
    print()

async def main():
    OUT.mkdir(exist_ok=True); bodies={}
    async with async_playwright() as p:
        ctx=await p.chromium.launch_persistent_context(PROFILE,executable_path=CHROME,headless=False,args=["--profile-directory=Default"])
        page=ctx.pages[0]
        async def got(r):
            if re.search(r"/(master|v|a[0-9]+)\.m3u8$",r.url):
                try:bodies[r.url]=(await r.body()).decode("utf-8","replace")
                except:pass
        page.on("response",got)
        await page.goto(MOVIE,wait_until="domcontentloaded",timeout=90000)
        print("[ACTION] Bam Play...")
        await page.wait_for_timeout(35000)
        master=next((b for u,b in bodies.items() if u.endswith("/master.m3u8")),None)
        video=next((b for u,b in bodies.items() if u.endswith("/v.m3u8")),None)
        audio=None
        for u,b in bodies.items():
            if re.search(r"/a[0-9]+\.m3u8$",u):audio=b;break
        await ctx.close()
    if not video or not audio:raise SystemExit("Chua bat du video/audio. Chay lai va bam Play.")

    state={"video":0,"audio":0}
    tv=threading.Thread(target=worker,args=("video",video,state),daemon=True)
    ta=threading.Thread(target=worker,args=("audio",audio,state),daemon=True)
    tv.start();ta.start()
    print("[BUFFER] Dang chuan bi 5 segment dau...")
    while min(state["video"],state["audio"])<BUFFER:
        if not tv.is_alive() or not ta.is_alive():raise SystemExit("Worker dung truoc khi du buffer.")
        time.sleep(1)

    master_local='#EXTM3U\n#EXT-X-VERSION:7\n#EXT-X-MEDIA:TYPE=AUDIO,GROUP-ID="aud",NAME="Audio",DEFAULT=YES,AUTOSELECT=YES,URI="audio.m3u8"\n#EXT-X-STREAM-INF:BANDWIDTH=30000000,AUDIO="aud"\nvideo.m3u8\n'
    pl=OUT/"master.m3u8";pl.write_text(master_local,encoding="utf-8")
    print("\n[PLAY] VLC mo ngay. Tai tiep o nen.")
    if VLC.exists():subprocess.Popen([str(VLC),str(pl.resolve())])
    tv.join();ta.join()
    print("\n[DONE] Full cache hoan tat.")

asyncio.run(main())
