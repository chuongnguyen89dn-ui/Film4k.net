import asyncio,re,subprocess,time,math
from pathlib import Path
from urllib.request import Request,urlopen
from playwright.async_api import async_playwright

MOVIE="https://film4k.net/movie/spider-man-brand-new-day"
CHROME=r"C:\Users\Trinh\AppData\Local\Chromium\Application\chrome.exe"
PROFILE=r"C:\Users\Trinh\AppData\Local\Chromium\User Data"
VLC=Path(r"C:\Program Files\VideoLAN\VLC\vlc.exe")
OUT=Path("film4k_seek")
UA="Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/150.0.0.0 Safari/537.36"
PNG=b"\x89PNG\r\n\x1a\n"
TARGET=30*60
PRE=2
POST=6

def png_end(b):
    if not b.startswith(PNG): return 0
    p=8
    while p+12<=len(b):
        n=int.from_bytes(b[p:p+4],"big"); typ=b[p+4:p+8]; e=p+n+12
        if e>len(b): return 0
        if typ==b"IEND": return e
        p=e
    return 0

def get_clean(url,tries=12):
    last=None
    for n in range(tries):
        try:
            with urlopen(Request(url,headers={"User-Agent":UA,"Accept":"*/*"}),timeout=60) as r:b=r.read()
            k=png_end(b); return b[k:] if k else b
        except Exception as e:
            last=e
            print(f"[RETRY {n+1}/{tries}] {type(e).__name__}: {e}")
            time.sleep(min(2+n*2,15))
    raise last

def parse(body):
    init=None; segs=[]; durs=[]
    for s in body.splitlines():
        s=s.strip()
        if s.startswith("#EXT-X-MAP:"):
            m=re.search(r'URI="([^"]+)"',s)
            if m:init=m.group(1)
        elif s.startswith("#EXTINF:"):
            try:durs.append(float(s.split(":",1)[1].split(",",1)[0]))
            except:durs.append(20.0)
        elif s and not s.startswith("#") and "workers.dev/tt/" in s:
            segs.append(s)
    return init,segs,durs

def idx_at(durs,t):
    x=0.0
    for i,d in enumerate(durs):
        if x+d>t:return i,x
        x+=d
    return max(0,len(durs)-1),x-(durs[-1] if durs else 0)

def make_clip(prefix,body,target):
    init,segs,durs=parse(body)
    if not init or not segs: raise RuntimeError(prefix+" playlist invalid")
    i,start=idx_at(durs,target)
    a=max(0,i-PRE); b=min(len(segs),i+POST+1)
    ip=OUT/f"{prefix}_init.mp4"; ip.write_bytes(get_clean(init))
    lines=["#EXTM3U","#EXT-X-VERSION:7","#EXT-X-TARGETDURATION:30","#EXT-X-MEDIA-SEQUENCE:0",f'#EXT-X-MAP:URI="{ip.name}"']
    for j in range(a,b):
        fn=f"{prefix}_{j:04}.m4s"
        (OUT/fn).write_bytes(get_clean(segs[j]))
        d=durs[j] if j<len(durs) else 20.0
        lines += [f"#EXTINF:{d:.3f},",fn]
        print(f"[{prefix}] segment {j+1}/{len(segs)}")
    lines.append("#EXT-X-ENDLIST")
    (OUT/f"{prefix}.m3u8").write_text("\n".join(lines)+"\n",encoding="utf-8")
    return i,start,a,sum(durs[a:i])

async def main():
    OUT.mkdir(exist_ok=True); bodies={}
    async with async_playwright() as p:
        ctx=await p.chromium.launch_persistent_context(PROFILE,executable_path=CHROME,headless=False,args=["--profile-directory=Default"])
        page=ctx.pages[0]
        async def got(r):
            if re.search(r"/(master|v|a[0-9]+)\.m3u8$",r.url):
                try:bodies[r.url]=(await r.body()).decode("utf-8","replace")
                except:pass
        page.on("response",got)
        await page.goto(MOVIE,wait_until="domcontentloaded",timeout=90000)
        print("[ACTION] Bam Play. Script se test nhay thang toi phut 30.")
        await page.wait_for_timeout(35000)
        video=next((b for u,b in bodies.items() if u.endswith("/v.m3u8")),None)
        audio=next((b for u,b in bodies.items() if re.search(r"/a[0-9]+\.m3u8$",u)),None)
        await ctx.close()
    if not video or not audio: raise SystemExit("Chua bat du video/audio.")

    vi,vs,va,voff=make_clip("video",video,TARGET)
    ai,ass,aa,aoff=make_clip("audio",audio,TARGET)
    master='#EXTM3U\n#EXT-X-VERSION:7\n#EXT-X-MEDIA:TYPE=AUDIO,GROUP-ID="aud",NAME="Audio",DEFAULT=YES,AUTOSELECT=YES,URI="audio.m3u8"\n#EXT-X-STREAM-INF:BANDWIDTH=30000000,AUDIO="aud"\nvideo.m3u8\n'
    pl=OUT/"master.m3u8"; pl.write_text(master,encoding="utf-8")
    print(f"[SEEK TEST] target=30:00 video_segment={vi+1} audio_segment={ai+1}")
    print("[PLAY] VLC se mo clip quanh moc 30:00. Kiem tra hinh + tieng.")
    if VLC.exists(): subprocess.Popen([str(VLC),str(pl.resolve())])

asyncio.run(main())
